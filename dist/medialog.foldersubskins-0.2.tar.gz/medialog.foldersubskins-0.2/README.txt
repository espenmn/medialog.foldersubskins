Changelog
=========

This product adds a field to folders so you can define extra.css you want to load for content in that folder. Requires medialog.subskins 4.1b3 or higher and Products.PloneSubSkins 4.5

0.1
----------------------
First version