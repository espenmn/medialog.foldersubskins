from zope.interface import Interface
from plone.theme.interfaces import IDefaultPloneLayer

class IFolderSubskinsLayer(IDefaultPloneLayer):
    """A Layer Specific to FolderSubskins"""